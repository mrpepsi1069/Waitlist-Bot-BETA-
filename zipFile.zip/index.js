const fs = require("fs");
const path = require("path");
require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  Collection,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.commands = new Collection();

// Load commands
const commandsPath = path.join(__dirname, "commands");
for (const file of fs.readdirSync(commandsPath)) {
  const cmd = require(path.join(commandsPath, file));
  client.commands.set(cmd.data.name, cmd);
  console.log("Loaded command:", cmd.data.name);
}

// Autocomplete for waitlists
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isAutocomplete()) return;

  const focused = interaction.options.getFocused();
  const waitlists = fs.readdirSync("./waitlists").map(l => l.replace(".json", ""));

  const filtered = waitlists.filter(w => w.toLowerCase().includes(focused.toLowerCase()));

  return interaction.respond(filtered.map(w => ({ name: w, value: w })));
});

// Slash commands
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const cmd = client.commands.get(interaction.commandName);
  if (!cmd) return;

  try {
    await cmd.execute(interaction);
  } catch (err) {
    console.error(err);
    return interaction.reply({ content: "❌ An error occurred.", ephemeral: true });
  }
});

// Update button – ANYONE can click
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId.startsWith("update_")) {
    const name = interaction.customId.replace("update_", "");
    const file = `./waitlists/${name}.json`;

    if (!fs.existsSync(file))
      return interaction.reply({ content: "❌ Waitlist does not exist.", ephemeral: true });

    const data = JSON.parse(fs.readFileSync(file));

    const embed = new EmbedBuilder()
      .setTitle(`📋 Waitlist: ${name}`)
      .setColor("Blue")
      .setDescription(
        data.users.length
          ? data.users.map((id, i) => `${i + 1}. <@${id}>`).join("\n")
          : "No users in this waitlist."
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`update_${name}`)
        .setLabel("Update")
        .setStyle(ButtonStyle.Primary)
    );

    return interaction.update({ embeds: [embed], components: [row] });
  }
});

client.login(process.env.TOKEN);
