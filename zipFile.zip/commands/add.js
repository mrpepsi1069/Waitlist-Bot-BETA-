const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("add")
    .setDescription("Add a user to a waitlist.")
    .addUserOption(opt =>
      opt.setName("user").setDescription("User to add").setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName("waitlist")
        .setDescription("Waitlist name")
        .setRequired(true)
        .setAutocomplete(true)
    ),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const configFile = `./configs/${guildId}.json`;

    if (!fs.existsSync(configFile))
      return interaction.reply({
        content: "❌ This server has not run **/setup** yet.",
        ephemeral: true
      });

    const config = JSON.parse(fs.readFileSync(configFile));

    // permission check
    const isManager = interaction.member.roles.cache.has(config.managerRoleId);
    const isAdmin = interaction.member.permissions.has("Administrator");

    if (!isManager && !isAdmin)
      return interaction.reply({
        content: "❌ You cannot add to waitlists.",
        ephemeral: true
      });

    const user = interaction.options.getUser("user");
    const list = interaction.options.getString("waitlist");
    const file = `./waitlists/${list}.json`;

    if (!fs.existsSync(file))
      return interaction.reply({ content: "❌ Waitlist does not exist.", ephemeral: true });

    const data = JSON.parse(fs.readFileSync(file));

    if (data.users.includes(user.id))
      return interaction.reply({ content: "❌ User already on the list.", ephemeral: true });

    data.users.push(user.id);
    fs.writeFileSync(file, JSON.stringify(data, null, 2));

    interaction.reply({
      content: `✔ Added **${user.username}** to **${list}**.`,
      ephemeral: true
    });
  }
};
