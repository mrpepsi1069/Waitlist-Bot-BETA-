const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("remove")
    .setDescription("Remove a user from a waitlist.")
    .addUserOption(opt =>
      opt.setName("user").setDescription("User to remove").setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName("waitlist")
        .setDescription("Waitlist name")
        .setRequired(true)
        .setAutocomplete(true)
    ),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const configFile = `./configs/${guildId}.json`;

    if (!fs.existsSync(configFile))
      return interaction.reply({
        content: "❌ This server has not run **/setup** yet.",
        ephemeral: true
      });

    const config = JSON.parse(fs.readFileSync(configFile));

    // permissions
    const isManager = interaction.member.roles.cache.has(config.managerRoleId);
    const isAdmin = interaction.member.permissions.has("Administrator");

    if (!isManager && !isAdmin)
      return interaction.reply({
        content: "❌ You cannot remove from waitlists.",
        ephemeral: true
      });

    const user = interaction.options.getUser("user");
    const list = interaction.options.getString("waitlist");
    const file = `./waitlists/${list}.json`;

    if (!fs.existsSync(file))
      return interaction.reply({ content: "❌ Waitlist not found.", ephemeral: true });

    const data = JSON.parse(fs.readFileSync(file));

    if (!data.users.includes(user.id))
      return interaction.reply({
        content: "❌ User is not on this list.",
        ephemeral: true
      });

    data.users = data.users.filter(id => id !== user.id);
    fs.writeFileSync(file, JSON.stringify(data, null, 2));

    interaction.reply({
      content: `✔ Removed **${user.username}** from **${list}**.`,
      ephemeral: true
    });
  }
};
