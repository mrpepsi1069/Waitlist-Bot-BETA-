const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setwaitlist")
    .setDescription("Post a waitlist with update button.")
    .addStringOption(opt =>
      opt.setName("waitlist")
        .setDescription("Waitlist name")
        .setRequired(true)
        .setAutocomplete(true)
    ),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const configFile = `./configs/${guildId}.json`;

    if (!fs.existsSync(configFile))
      return interaction.reply({
        content: "❌ This server has not run **/setup** yet.",
        ephemeral: true
      });

    const config = JSON.parse(fs.readFileSync(configFile));

    const channel = interaction.guild.channels.cache.get(config.storageChannelId);

    if (!channel)
      return interaction.reply({
        content: "❌ The waitlist channel from /setup no longer exists.",
        ephemeral: true
      });

    const isManager = interaction.member.roles.cache.has(config.managerRoleId);
    const isAdmin = interaction.member.permissions.has("Administrator");

    if (!isManager && !isAdmin)
      return interaction.reply({
        content: "❌ You cannot set waitlists.",
        ephemeral: true
      });

    const list = interaction.options.getString("waitlist");
    const file = `./waitlists/${list}.json`;

    if (!fs.existsSync(file))
      return interaction.reply({ content: "❌ Waitlist not found.", ephemeral: true });

    const data = JSON.parse(fs.readFileSync(file));

    const embed = new EmbedBuilder()
      .setTitle(`📋 Waitlist: ${list}`)
      .setColor("Blue")
      .setDescription(
        data.users.length
          ? data.users.map((id, i) => `${i + 1}. <@${id}>`).join("\n")
          : "No users yet."
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`update_${list}`)
        .setLabel("Update")
        .setStyle(ButtonStyle.Primary)
    );

    await channel.send({ embeds: [embed], components: [row] });

    interaction.reply({
      content: `✔ Waitlist **${list}** posted in <#${channel.id}>.`,
      ephemeral: true
    });
  }
};
