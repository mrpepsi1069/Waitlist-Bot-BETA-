// commands/setup.js
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");
const fs = require("fs");
const path = require("path");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configure the waitlist bot for this server.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(opt =>
      opt.setName("manager_role")
        .setDescription("Role allowed to create & edit waitlists")
        .setRequired(true)
    )
    .addChannelOption(opt =>
      opt.setName("storage_channel")
        .setDescription("Channel where waitlists will be posted")
        .setRequired(true)
    ),

  async execute(interaction) {
    const managerRole = interaction.options.getRole("manager_role");
    const storageChannel = interaction.options.getChannel("storage_channel");

    const guildId = interaction.guild.id;
    const configPath = path.join(__dirname, "..", "configs");

    if (!fs.existsSync(configPath)) fs.mkdirSync(configPath);

    const config = {
      guildId,
      managerRoleId: managerRole.id,
      storageChannelId: storageChannel.id
    };

    fs.writeFileSync(
      path.join(configPath, `${guildId}.json`),
      JSON.stringify(config, null, 2)
    );

    const embed = new EmbedBuilder()
      .setTitle("✔ Waitlist Bot Setup Complete")
      .setColor("Green")
      .setDescription(
        `Your server is now configured.\n\n**Manager Role:** <@&${managerRole.id}>\n**Waitlist Channel:** <#${storageChannel.id}>\n\nUsers with the manager role can:\n• Create waitlists\n• Add/remove users\n• Post waitlists\n\n**Everyone can press update buttons.**`
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
