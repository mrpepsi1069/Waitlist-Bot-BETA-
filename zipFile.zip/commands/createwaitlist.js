const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("createwaitlist")
    .setDescription("Create a new waitlist.")
    .addStringOption(opt =>
      opt.setName("name")
        .setDescription("Waitlist name")
        .setRequired(true)
    ),

  async execute(interaction) {
    const guildId = interaction.guild.id;
    const configFile = `./configs/${guildId}.json`;

    if (!fs.existsSync(configFile))
      return interaction.reply({
        content: "❌ This server has not run **/setup** yet.",
        ephemeral: true
      });

    const config = JSON.parse(fs.readFileSync(configFile));

    const isManager = interaction.member.roles.cache.has(config.managerRoleId);
    const isAdmin = interaction.member.permissions.has("Administrator");

    if (!isManager && !isAdmin)
      return interaction.reply({
        content: "❌ You cannot create waitlists.",
        ephemeral: true
      });

    const name = interaction.options.getString("name");
    const file = `./waitlists/${name}.json`;

    if (fs.existsSync(file))
      return interaction.reply({ content: "❌ That waitlist already exists.", ephemeral: true });

    fs.writeFileSync(file, JSON.stringify({ users: [] }, null, 2));

    interaction.reply({
      content: `✔ Created waitlist **${name}**.`,
      ephemeral: true
    });
  }
};
